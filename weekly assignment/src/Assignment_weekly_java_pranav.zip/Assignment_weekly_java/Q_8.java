/*8.Write a Java program to create consumer-producer applications by using multiple consumers
as well as multiple producers*/
package Assignment_weekly_java;


public class Q_8 {
    public static void main(String[] args) {
        
    }
    
}
