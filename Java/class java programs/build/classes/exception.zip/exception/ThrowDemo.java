
package exception;


public class ThrowDemo {
    public static void main(String[] args) {
       VoterValidity vv=new VoterValidity();
          vv.checkvalidity();
                  
    }
   
    
}
